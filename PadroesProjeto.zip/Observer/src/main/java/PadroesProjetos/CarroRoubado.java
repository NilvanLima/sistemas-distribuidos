package PadroesProjetos;

import java.util.Observable;

public class CarroRoubado extends Observable implements Carro {

    private String acao = "";

    @Override
    public void frente() {
        acao = "frente";
        System.out.println("Carro roubado segue em frente");
        this.mudarEstado();
    }

    //override = executa esse em vez do que está herdando em geral
    @Override
    public void direita() {
        acao = "direita";
        System.out.println("Carro roubado virou a direita");
        this.mudarEstado();
    }

    @Override
    public void esquerda() {
        acao = "esquerda";
        System.out.println("Carro roubado virou a esquerda");
        this.mudarEstado();
    }

    @Override
    public void parar() {
        acao = "parar";
        System.out.println("Carro roubado parou");
        this.mudarEstado();
    }

    public void mudarEstado() {
        setChanged(); //método do Observable, quando for acionado vai mudar o estado (notificar os demais)
        notifyObservers(acao); //vai passar essa mudança para as viaturas
    }
}
