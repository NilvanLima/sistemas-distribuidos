package PadroesProjetos;

import java.util.Observable;
import java.util.Observer;

public class CarroTiras implements Observer, Carro {
    //se o observado mudar, o observador tem que mudar

    @Override
    public void update(Observable arg0, Object arg1) { //update saiu do Obsever
        CarroRoubado carroRoubado = (CarroRoubado) arg0;
        String acao = String.valueOf(arg1); //pega o valor do objeto 'acao' do CarroRoubado
        if (acao.equalsIgnoreCase("frente")) { //equalsIgnoreCase = vai comparar a ação com a String
            this.frente();
        } else if (acao.equalsIgnoreCase("direita")) { //equalsIgnoreCase = vai comparar a ação com a String
            this.direita();
        }else if (acao.equalsIgnoreCase("esquerda")) { //equals vai diferenciar maiuscula e minusculas, ignoreCase não, vai considerar tudo
            this.esquerda();
        }else if (acao.equalsIgnoreCase("parar")) { 
            this.parar();
        }
    }
    //não tem ação pois a ação vem do CarroRoubado

    @Override
    public void frente() {
        System.out.println("Viatura segue em frente");
    }

    @Override
    public void direita() {
        System.out.println("A viatura vira a direita");
    }

    @Override
    public void esquerda() {
        System.out.println("A viatura vira a esquerda");
    }

    @Override
    public void parar() {
        System.out.println("A viatura parou");
    }

}
