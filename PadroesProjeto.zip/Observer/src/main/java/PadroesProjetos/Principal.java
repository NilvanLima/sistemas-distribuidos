package PadroesProjetos;

public class Principal {
    public static void main(String[] args) {
        CarroTiras carroDeTiras = new CarroTiras();
        CarroRoubado carroRoubado = new CarroRoubado();
        
        //carro roubado é o observado e o de tiras, observador
        carroRoubado.addObserver(carroDeTiras);
        carroRoubado.frente();
        carroRoubado.direita();
        carroRoubado.esquerda();
        carroRoubado.parar();                
    }
}
