package PadroesProjetos;

public interface Carro {
    
    public void frente ();
    public void direita();
    public void esquerda();
    public void parar();
}
